
from function import *

base = 2
height = 5
length = 10
print(calulate_triangle_area(base, height))
print(calculate_square_area(length))