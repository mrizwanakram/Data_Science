#Calculate area of triangle
base = 10
height = 5
area = 1/2 * (base * height)
print("Area of triangle is : ",area)
